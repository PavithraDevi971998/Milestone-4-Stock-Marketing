package com.example.stockspring.service;

import com.example.stockspring.model.Company;

public interface CompanyRefService {
public void insertCompany(Company company);
}
